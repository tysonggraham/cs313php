<?php 

//Get the user's input
$fixings = $_POST["fixings"];
$meat = $_POST["meat"];
$rice = $_POST["rice"];
$beans = $_POST["beans"];
$medium = $_POST["medium"];
$tomato_stuff = $_POST["tomato_stuff"];

#Hide a lot of the boring stuff
require "resultsphpheader.php";

 ?>
      
<!DOCTYPE html>
<html>
<head>
	<title>Results</title>
	<script medium="text/javascript" src="survey.js"></script>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link rel="stylesheet" medium="text/css" href="survey.css">
	<script type="text/javascript" src="sources/jscharts.js"></script>
	<script type="text/javascript" src="results.js"></script>
	<script type="text/javascript">
      // google.charts.load('current', {'packages':['corechart']});
      // google.charts.setOnLoadCallback(drawCharts);

      // function drawCharts() {

      	// var meatsArray = [<?php echo json_encode($meats); ?>];
      	// var beansArray = [<?php echo json_encode($beans); ?>];
      	// var riceArray = [<?php echo json_encode($rice); ?>];
      	// var mediumsArray = [<?php echo json_encode($mediums); ?>];
      	// var tomatoArray = [<?php  echo json_encode($tomato_stuff); ?>];
      	// var fixingsArray = [<?php echo json_encode($fixings); ?>]

      // 	drawMeatChart();
      // 	drawBeansChart();
      // 	drawRiceChart();
      // 	drawTortillaChart();
      // 	drawTomatoChart();
      // 	drawFixingsChart();           
      // }

  //     	var meatyData = new([
		//   ['Carne Asada', meatsArray[0].Carne_Asada],
		//   ['Chicken',     meatsArray[0].Chicken],
		//   ['Carnitas',    meatsArray[0].Carnitas],
		//   ['Ground Beef', meatsArray[0].Ground_Beef],
		//   ['Fish',        meatsArray[0].Fish],
		//   ['Vegetairan',  meatsArray[0].Vegetarian]
		// ]);

		function drawMeatChart() {
			var meatsArray = [<?php echo json_encode($meats); ?>];

			var myData = new Array(['Carne Asada', meatsArray[0].Carne_Asada]);
			var colors = ['#FACC00', '#FB9900', '#FB6600', '#FB4800', '#CB0A0A', '#F8F933'];
			var myChart = new JSChart('meatchart', 'pie');

			myChart.setDataArray(myData);
			myChart.colorizePie(colors);
			myChart.setTitleColor('#857D7D');
			myChart.setPieUnitsColor('#9B9B9B');
			myChart.setPieValuesColor('#6A0000');
			myChart.draw();

			// var meatyOptions = {
			//          title: 'Favorite meats: '
			//    };

			//    var chart = new google.visualization.PieChart(document.getElementById('meatchart'));

			//    chart.draw(meatyData, meatyOptions);
		}


      function selChart(choice) {
	    $("meatchart").hide();
      	$("ricechart").hide();
      	$("beanschart").hide();
      	$("mediumchart").hide();
      	$("tomatochart").hide();
      	$("fixingschart").hide();  

      	if (choice === "meats") {
      		$("meatchart").show();      		
      	}
      	if (choice === "beans") {
  			$("beanschart").show();	
      	}
      	if (choice === "rice") {
      		$("ricechart").show();
      	}
      	if (choice === "tortilla") {
      		$("mediumchart").show();
      	}
      	if (choice === "tomato") {
      		$("tomatochart").show();
      	}
      	if (choice === "fixings") {
      		$("fixingschart").show();
      	}
      }
    </script>    
</head>
<body>
	<script>drawMeatChart()</script

	<div id="meatchart" class="chart"></div>
	<p></p>
	<div id="ricechart" class="chart"></div>
	<p></p>
	<div id="beanschart" class="chart"></div>
	<p></p>
	<div id="mediumchart" class="chart"></div>
	<p></p>
	<div id="tomatochart" class="chart"></div>
	<p></p>
	<div id="fixingschart" class="chart"></div>
	<p></p>
</body>
</html>